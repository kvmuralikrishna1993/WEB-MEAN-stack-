export class Product {
    prodId: number;
    productTitle: string;
    productCategory: string;
    productDescription: string[];
    img: string;
    quantity: number;
    price: number;
    uRQ: number;
    rating: number;
}