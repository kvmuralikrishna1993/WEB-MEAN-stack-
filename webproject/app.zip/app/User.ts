export class User {
    uID: number;
    username:string;
    password:string;
    mobilenum: number;
    email: string;
    date:number;
    address: string[];
    isLoggedIn: boolean;
    cart_details: number [];
}