export class Product {
    
}